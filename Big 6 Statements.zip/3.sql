SELECT Store_id,count(active) as Active_Customers FROM mavenmovies.customer
Where active=1
Group by Store_id

