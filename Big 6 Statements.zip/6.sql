	SELECT Min(replacement_cost) 'Minimum replacement Cost',Max(replacement_cost)'Maximum replacement Cost',round(Avg(replacement_cost),2) 'Average replacement Cost' FROM mavenmovies.film
   