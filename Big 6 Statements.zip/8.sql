SELECT Customer_id,count(rental_id) 'Rental Counts' FROM mavenmovies.rental
Group by customer_id
order by count(rental_id) desc