SELECT  store_id as 'Store ID',count(distinct (film_id)) as 'Unique film titles' FROM mavenmovies.inventory
Group by store_id