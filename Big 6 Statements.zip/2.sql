SELECT Store_id,count(inventory_id) as Inventory_Items FROM mavenmovies.inventory
Group by store_id