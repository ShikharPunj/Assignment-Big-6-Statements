SELECT count(distinct (category_id)) 'Unique Category of Films
' FROM mavenmovies.film_category
